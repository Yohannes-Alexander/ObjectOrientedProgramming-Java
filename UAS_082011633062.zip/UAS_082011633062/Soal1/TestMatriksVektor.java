package UAS_082011633062.Soal1;
import java.util.Scanner;

public class TestMatriksVektor {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Matriks m = new Matriks();
        System.out.println("MATRIKS M");
        m.displayMatriks();System.out.println();
        
        System.out.print("INGIN DIURUTKAN DARI KOLOM = ");
        int col = input.nextInt();System.out.println();
        

        Vektor v = new Vektor(m, col);
        System.out.println("VEKTOR V");
        System.out.print("V = ");
        v.display();System.out.println();

        Vektor v_urut = v.sortVektor(v);
        System.out.println("VEKTOR V YANG SUDAH DIURUTKAN");
        System.out.print("V_URUT = ");
        v_urut.display();System.out.println();

        Vektor v_indeks = v.indeks_urut_vektor(v);
        System.out.println("VEKTOR YANG BERISI INDEKS DARI VEKTOR V_URUT");
        System.out.print("V_Indeks = ");
        v_indeks.display();System.out.println("\n");

        // Matriks n = new Matriks();
        Matriks n = m.urut_matriks(m, v_indeks);
        System.out.println("MATRIKS N YANG MERUPAKAN MATRIKS M YANG DIURUTKAN DARI KOLOM "+col);
        n.displayMatriks();
    }
}
