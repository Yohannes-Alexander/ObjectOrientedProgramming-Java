package UAS_082011633062.Soal1;
import java.util.Scanner;

public class Matriks {
    private int [][] elemen ={{3,4,6},{1,7,2},{5,11,8},{2,9,14}};
    private int row;
    private int col;
    
    public Matriks(){
        this.row = 4;
        this.col = 3;
    }

    public Matriks(int row, int col){
        this.row = row;
        this.col = col;
        System.out.println("Masukkan nilai Matriks");
        this.elemen = new int[this.row][this.col];
        Scanner input = new Scanner(System.in);
        for (int i = 0 ; i < this.row;i++){
            System.out.println("Baris ke-"+i);
            for (int j = 0 ; j < this.col ; j++){
                System.out.print("Masukkan nilai elemen ke-"+j);
                this.elemen[i][j] = input.nextInt();
            }
            System.out.println("=======================");
        }
    }

    public Matriks urut_matriks(Matriks m ,Vektor v_indeks){
        Matriks n = new Matriks();
        n.setRow(m.getRow());
        n.setCol(m.getCol());

        for(int j=0;j<m.getRow();j++){
            for(int k=0;k<m.getCol();k++){
                n.setElemen(j, k, m.getElemen(v_indeks.getElemen(j), k));
            }
        }
        return n;
    }

    public void displayMatriks(){
        for(int i = 0 ; i < this.row;i++){
            for(int j = 0 ; j < this.col;j++){
                System.out.print(this.elemen[i][j]+" ");
            }
            System.out.println();
        }
    }

    public int getElemen(int row,int col){return this.elemen[row][col];}
    public int getRow(){return this.row;}
    public int getCol(){return this.col;}
    public void setRow(int row){this.row = row;}
    public void setCol(int col){this.col = col;}
    public void setElemen(int row, int col,int elemen){this.elemen[row][col] = elemen;}
    

}
