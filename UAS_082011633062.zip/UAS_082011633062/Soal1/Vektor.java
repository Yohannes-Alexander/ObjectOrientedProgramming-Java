package UAS_082011633062.Soal1;

public class Vektor {
    private int [] elemen;
    private int size;

    // public Vektor(){}

    public Vektor(int size){
        this.size = size;
        this.elemen = new int[this.size];
    }
    
    public Vektor(int[] elemen){
        this.elemen = elemen.clone();
        this.size = this.elemen.length;
    }
    
    public Vektor(Matriks matriks,int col){
        this.elemen = new int[matriks.getRow()];
        this.size = this.elemen.length;
        for (int i = 0 ; i < this.size ; i++){
            this.elemen[i]= matriks.getElemen(i, col-1);
        }
    }

    public Vektor sortVektor(Vektor v){
        int k;
        Vektor copy = new Vektor(v.getElemenAll());
        for (int i = 0 ; i < v.getSize()-1;i++){
            for (int j = i ; j < v.getSize();j++){
                if(copy.getElemen(i)>copy.getElemen(j)){
                    k = copy.getElemen(i);
                    copy.setElemen(i, copy.getElemen(j));
                    copy.setElemen(j, k);
                }
            }
        }
        return copy;
    }
    
    public Vektor indeks_urut_vektor(Vektor v){
        Vektor v_indeks = new Vektor(v.getSize());
        Vektor v_urut = sortVektor(v);
        int indeks = 0 ;
        for(int i = 0 ; i < v_indeks.getSize();i++){
            for(int j = 0 ; j < v_indeks.getSize();j++){
               if(v.getElemen(j)==v_urut.getElemen(i)){
                    v_indeks.setElemen(indeks, j);
                    indeks ++;
                    continue;
                } 
            }
            
        }
        return v_indeks;
    }

    public void display(){
        for(int i = 0 ;i<this.size;i++){
            if(i==0){
                System.out.print("( "+this.elemen[i]+", ");
            }
            else if(i==this.size-1){
                System.out.print(this.elemen[i]+" )");
            }
            else{
                System.out.print(this.elemen[i]+", ");
            }
            
        }
    }

    public int getSize(){return this.size;}
    public int getElemen(int indeks){return this.elemen[indeks];}
    public int[] getElemenAll(){return this.elemen;}
    public void setElemen(int indeks,int elemen){this.elemen[indeks]=elemen;}
    public void setElemenAll(int[] element){this.elemen = element.clone();}
    public void setSize(int size){this.size = size;}
}
