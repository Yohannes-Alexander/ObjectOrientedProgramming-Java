package UAS_082011633062.Soal2;
import java.util.ArrayList;

public class Universitas {
    private static String namaUniversitas;
    private ArrayList<Mahasiswa> mahasiswa;
    private int incrementalId;
    
    public Universitas(String namaUniversitas){
        this.mahasiswa = new ArrayList<>();
        this.namaUniversitas = namaUniversitas;
        this.incrementalId = 1;
    }

    public static void setNamaUniversitas(String namaUniversitas){
        Universitas.namaUniversitas=namaUniversitas;
    }
    public int getIncrementalId(){
        return this.incrementalId;
    }
    public static String getNamaUniversitas(){
        return Universitas.namaUniversitas;
    }
    public void addMahasiswa(Mahasiswa mahasiswa){
        this.mahasiswa.add(mahasiswa);
        this.incrementalId ++;
    }

    public void removeMahasiswa(String nim){
        for(int i = 0 ; i < this.mahasiswa.size();i++){
            if(this.mahasiswa.get(i).getNim().equals(nim)){
                this.mahasiswa.remove(i);
            }
        }
    }

    public int getTotalStudent(){return this.mahasiswa.size();}

    public void displayMahasiswa(){
        for(int i = 0 ; i < this.mahasiswa.size();i++){
            System.out.println("Mahasiswa "+(i+1));
            System.out.println("NIM : "+this.mahasiswa.get(i).getNim());
            System.out.println("Nama : "+this.mahasiswa.get(i).getNama());
            System.out.println("Alamat : "+this.mahasiswa.get(i).getAlamat());
            System.out.println("Jurusan : "+this.mahasiswa.get(i).getJurusan());
            System.out.println();
        }
    }
}
