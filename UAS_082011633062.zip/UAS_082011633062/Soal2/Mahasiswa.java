package UAS_082011633062.Soal2;

public class Mahasiswa extends WargaUniversitas{
    private String nim;
    private String jurusan;

    public Mahasiswa(String nim, String nama, String alamat, String jurusan){
        super(nama,alamat);
        this.nim = nim;
        this.jurusan = jurusan;
    }

    public void setNim(String nim){this.nim = nim;}
    public void setJurusan(String jurusan){this.jurusan = jurusan;}
    public String getNim(){return this.nim;}
    public String getJurusan(){return this.jurusan;}
}
