package UAS_082011633062.Soal2;
import java.util.Scanner;

public class TestMain {
    public static void main(String[] args) {
        System.out.println("WELCOME TO COLLEGE DATA INPUT APPLICATION");
        Scanner input = new Scanner(System.in);
        System.out.print("INPUT UNIVERSITY NAME : ");
        String nama = input.nextLine(); 
        Universitas university1 = new Universitas(nama);System.out.println();
        // boolean test = true;
        System.out.println("INPUT DATA STUDENT");
        while (true){
            System.out.println("Student ID : "+university1.getIncrementalId());
            System.out.print("INPUT STUDENT NAME : ");
            String name = input.nextLine();
            System.out.print("INPUT ALAMAT NAME : ");
            String address = input.nextLine();
            System.out.print("INPUT MAJOR NAME : ");
            String major = input.nextLine();
            switch (major) {
                case "61":
                    major = "MATEMATIKA";
                    break;
                case "62":
                    major = "BIOLOGI";
                    break;
                case "63":
                    major = "KIMIA";
                    break;
                case "64":
                    major = "FISIKA";
                    break;
                case "65":
                    major = "TEKNIK INFORMATIKA";
                    break;
                case "66":
                    major = "TEKNIK ARSITEKTUR";
                    break;
                default:
                    System.out.println("NOT FOUND");
                    break;
            }
            university1.addMahasiswa(new Mahasiswa(String.valueOf(university1.getIncrementalId()), name, address, major));
            
            System.out.print("DO YOU WANT TO ADD ANOTHER INPUT ? (Y/N) : ");
            String control = input.nextLine();System.out.println();
            if(control.toUpperCase().equals("N")){
                System.out.println();
                System.out.println("The total of inputted Student Data is "+university1.getTotalStudent()+" students");
                System.out.println();
                System.out.println("STUDENT DATA");
                university1.displayMahasiswa();
                break;
            }
        }
    }
}
