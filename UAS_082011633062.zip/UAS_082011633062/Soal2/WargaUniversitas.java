package UAS_082011633062.Soal2;

public class WargaUniversitas {
    private String nama;
    private String alamat;

    public WargaUniversitas(String nama, String alamat){
        this.nama = nama;
        this.alamat = alamat;
    }
    public void setAlamat(String alamat){this.alamat = alamat;}
    public void setNama(String nama){this.nama = nama;}
    public String getNama(){return this.nama;}
    public String getAlamat(){return this.alamat;}

}
